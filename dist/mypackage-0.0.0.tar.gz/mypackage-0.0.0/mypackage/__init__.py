from . import myModule

